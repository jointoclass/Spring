package com.dw.basicapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicappApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicappApplication.class, args);
	}

}
